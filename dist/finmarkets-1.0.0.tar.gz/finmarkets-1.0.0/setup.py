from setuptools import setup

setup(
    name='finmarkets',
    version='1.0.0',    
    description='A collection of financial tools developed during Financial Markets course at UniSi.',
    #url='https://github.com/shuds13/pyexample',
    author='Matteo Sani',
    author_email='matteo.sani@mpscapitalservices.it',
    #license='BSD 2-clause',
    #packages=['finmarkets'],
    py_modules=['finmarkets'],
    install_requires=['numpy',
                      'scipy'],

    classifiers=[
        'Development Status :: 5 - Production/Stable',
        'Environment :: Console',
        'Intended Audience :: Education',
        'License :: Free For Educational Use',  
        'Programming Language :: Python :: 3',
        'Natural Language :: English',
        'Topic :: Office/Business :: Financial'
    ],
)
