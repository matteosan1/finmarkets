from setuptools import setup

setup(
    name='finmarkets',
    version='0.2.0',    
    description='A collection of financial tools developed during Financial Markets course at UniSi.',
    #url='https://github.com/shuds13/pyexample',
    author='Matteo Sani',
    author_email='matteo.sani@mpscapitalservices.it',
    license='BSD 2-clause',
    #packages=['finmarkets'],
    py_modules=['finmarkets'],
    install_requires=['numpy',
                      'scipy'],

    classifiers=[
        'Development Status :: 1 - Planning',
        'Intended Audience :: Science/Research',
        'License :: OSI Approved :: BSD License',  
        'Programming Language :: Python :: 3',
    ],
)
